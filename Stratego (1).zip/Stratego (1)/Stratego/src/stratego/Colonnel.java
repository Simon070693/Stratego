/**
 * Classe colonnel herite de la classe Pion.
 */
package stratego;

/**
 * @author marie
 *
 */
public class Colonnel extends Pion{

	/**
	 * Constructeur de la classe colonnel.
	 */
	public Colonnel(int x, char y, int grade) {
		super(x, y, grade);
	}

}
