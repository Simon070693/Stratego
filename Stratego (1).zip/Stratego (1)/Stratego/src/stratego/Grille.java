/**
 * 
 */
package stratego;

/**
 * @author marie
 *
 */
public class Grille {
	int ligne;
	char [][]grille;
	int ligneColonne;
	
	/**
	 * Constructeur de la grille.
	 */
	public Grille() {
		this.ligne = 10;
		grille = new char [ligne][ligne];
		
	}
	
	

}
