/**
 * Classe Eclaireur herite de la classe Pion.
 */
package stratego;

/**
 * @author Marie
 * @date 12/11/14
 */
public class Eclaireur extends Pion{

	/**
	 * Constructeur d'un Eclaireur.
	 */
	public Eclaireur(int x, char y, int grade) {
		super(x, y, grade);
	}

}
