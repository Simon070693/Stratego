/**
 * Pion Sergent h�rite de la classe Pion.
 */
package stratego;

/**
 * @author Marie
 * @date 11/11/14
 */
public class Sergent extends Pion{

	/**
	 * Constructeur du pion Sergent.
	 */
	public Sergent(int x, char y, int grade) {
		super(x, y, grade);
	}
}
