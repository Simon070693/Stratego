/**
 * Classe general herite de la classe Pion.
 */
package stratego;

/**
 * @author marie
 *
 */
public class General extends Pion{

	/**
	 * Constructeur d'un general.
	 */
	public General(int x, char y, int grade) {
		super(x, y, grade);
	}

}
