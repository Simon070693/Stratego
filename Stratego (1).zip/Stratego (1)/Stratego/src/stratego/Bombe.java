/**
 * Pion Bombe h�rite de la classe Pion.
 */
package stratego;

/**
 * @author Marie
 * @date 12/11/14
 */

public class Bombe extends Pion{

	/**
	 * Constructeur d'un pion Bombe.
	 */
	public Bombe(int x, char y, char gradeC) {
		super(x, y, gradeC);
	}

}
