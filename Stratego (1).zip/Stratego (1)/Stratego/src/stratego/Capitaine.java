/**
 * Pion Capitaine h�rite de la classe Pion.
 */
package stratego;

/**
 * @author Marie
 * @date 11/11/14
 */
public class Capitaine extends Pion{
	
	/**
	 * Constructeur du pion Capitaine.
	 */
	public Capitaine(int x, char y, int grade) {
		super(x, y, grade);
	}
}
