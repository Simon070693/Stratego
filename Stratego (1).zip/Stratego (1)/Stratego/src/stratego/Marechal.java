/**
 * Classe marechal herite de la classe Pion.
 */
package stratego;

/**
 * @author marie
 *
 */
public class Marechal extends Pion{

	/**
	 * Constructeur d'un marechal.
	 */
	public Marechal(int x, char y, int grade) {
		super(x, y, grade);
	}

}
