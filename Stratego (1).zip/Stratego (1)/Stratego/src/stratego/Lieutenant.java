/**
 * Pion Lieutenant h�rite de la classe Pion.
 */
package stratego;

/**
 * @author Marie
 * @date 11/11/14
 */
public class Lieutenant extends Pion {

	/**
	 * Constructeur du pion Lieutenant.
	 */
	public Lieutenant(int x, char y, int grade) {
		super(x, y, grade);
	}
}
