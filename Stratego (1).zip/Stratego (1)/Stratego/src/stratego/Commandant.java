/**
 * Classe Commandant herite de la classe Pion.
 */
package stratego;

/**
 * @author marie
 *
 */
public class Commandant extends Pion{

	/**
	 * Constructeur d'un commandant.
	 */
	public Commandant(int x, char y, int grade) {
		super(x, y, grade);
	}

}
